See http://www.liferay.com/community/wiki/-/wiki/Main/Resources+Importer+Web
for more information about the Resources Importer.